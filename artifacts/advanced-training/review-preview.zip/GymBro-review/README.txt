Gym Bro 0.3.0 — approved A / Quiet focus review

This bundle contains unchanged approved main at site/ and the candidate at site/preview/.
It contains no user journal or photo data and starts with a separate empty preview journal.

Requires Node.js 22 or later. From this extracted folder run:
  node serve.mjs site
Then open:
  http://localhost:5173/preview/

This is a LOCAL preview address. It is not a hosted phone-accessible URL.
Do not open index.html directly with file://. The local server uses port 5173 by default.
Choose a different PORT environment variable if another service already uses it.
Localhost supports secure-context PWA APIs in compatible browsers; ordinary LAN HTTP
on a phone does not provide the same API guarantees.

Try Backup & Data in Settings; Focus Mode and Shorten workout during a session;
Training blocks in Programs; Feedback & notes on an exercise; Calendar export in Calendar.
To copy your own records into this preview, explicitly import a backup. No data syncs
back to the live application. Preserve your original backup file.

GitHub build/tests/composition passed, but Pages deployment was rejected because the
feature branch is not permitted by github-pages environment protection rules. Those
rules were retained. No alternate live candidate URL is claimed.

See site/preview/docs/advanced-training/REVIEW.md and QA.md for the full review and
known limitations. No merge to main or production release has been performed.
