/* Updates activate only after an explicit user request. */
const PREFIX='gymbro-'+self.registration.scope;
const CACHE=PREFIX+'1565f475a5c8';
const ASSETS=["./index.html","./src/analytics.js","./src/app-updates.css","./src/app-updates.js","./src/app.js","./src/appearance-init.js","./src/backup.js","./src/calendar.js","./src/coach-contract.js","./src/coach-local.js","./src/coach-session.js","./src/coach.js","./src/engine.js","./src/environment.js","./src/exercises.js","./src/extensions.js","./src/legacy-import.js","./src/model.js","./src/planner.js","./src/refinement.css","./src/storage.js","./src/style.css","./src/training-tools.js","./src/ui.js","./src/upgrade-controller.js","./src/upgrade-ui.js","./src/upgrade.css","./src/weekly-review-ui.js","./src/weekly-review.js","./icon-192.png","./icon-512.png","./icon.svg","./manifest-light.webmanifest","./manifest.webmanifest"];
const RELEASE={"schema":1,"version":"0.2.3","build":"1565f475a5c8","environment":"production","assets":{"index.html":"86e48a6e8c2b0f8b2191823ebe57e482db82546b007d9f9c8d1c5c0242d77926","src/analytics.js":"3d85557c1c63e60337fd60316ee2a037752b366f1a9af7933c3c67557a2d4af5","src/app-updates.css":"03726d4ccd5f4a45795d3d2512ab035e5039669e7eb256cb899f07b5bdd61022","src/app-updates.js":"0b5fe1b2bf7783b0333f54e92288d1e029dab045ef6ad89c19157c0fd7e207b5","src/app.js":"3fe1817c1b99a5cca2b7133b42dc7b05cf7f26264450b9721adec2cfb747ad6b","src/appearance-init.js":"189361ebfa9f9cf21d4c7569d277dc0d77f5b0ed42c4a9f374c6e862778ee325","src/backup.js":"8e969a66c58056e079fff7729630db87602e3d87c36e75d264026b752ea3ccc3","src/calendar.js":"204ea604e44c957c86c577258fc168d02946ec2c7e87de9dcfc56fd5e17959eb","src/coach-contract.js":"0f84c56f24ff220074a56c00a396dacb068132ce5d374e921b9724c111d8b192","src/coach-local.js":"0147d0189c8971040202118a15256098faa70245195325e09ebcc084d68c80ab","src/coach-session.js":"b44e3fa15cb016130c826139cbba41008e1bfaae9749fc5ab357c38d92e743ab","src/coach.js":"e639fd5f77a5c73a55038121a5c4080861847d1fa646d809b1fa887950f3069a","src/engine.js":"f72fdd8121d99a169b9d80bbb53418b2ba75b91d3e7cb8b8cab537d6e38ebd88","src/environment.js":"939d1403491493c0b75ac086acb657c99e7a81921590805c14a8a13d09b87d8f","src/exercises.js":"e03b586562c83b4f492185ad4a482a1e9e14d6df2caa6bc49e50c22dbc933038","src/extensions.js":"c685b0c6188f775eb7dca90046f8b85d6d26c0dec8a3bfa11b2724a57784b181","src/legacy-import.js":"a850541d5486e63d42de830901db37d3df4643932f514e0150c7abb684e62064","src/model.js":"9dc394ccb1cc023492a0b59e4cbb7abae6491095631e9cc3aedae18a10d01f16","src/planner.js":"c087d424aa916caddd34d7f098d83ec7f00d0ea3eab7f57afccbfc7247056c07","src/refinement.css":"e3eee204646e8933b36f32db91a274bb6d5315a6893f723a43526fd8f9b89ea3","src/storage.js":"157605f8dd3e1c7faeb8b5fb0202c350f363f03d719f9846a707aed5871beb05","src/style.css":"cd648e7d351bc95756f1448c53257c636f2013db1e980bac8e69e18e0df5bfae","src/training-tools.js":"8d3462e1c4ab97bb393fa6fab95fce3a0021e3647e3960f53de97a6c5473e658","src/ui.js":"a0bd77d243068a7f3b23494a95e2d2ba22e9c25db1cafb27b38ba97232364d67","src/upgrade-controller.js":"3ddf99bb7ed0b1144ab7a83fc31f6d34b810331a78d6580c8ad81da15226ad04","src/upgrade-ui.js":"7556ac2700a649ccd562c0a48b991373cdc104b9b8c5c224d3b4d8df8411ed12","src/upgrade.css":"b003ddee309e466b4f7040a7df097dc9b5f95ee19f5473aea8772fa77fb96f84","src/weekly-review-ui.js":"48f62e5496f275ddf727f2f47495208e6a79e45b984cea91c669fe3ac3dbc02f","src/weekly-review.js":"62a788c1e96469c7f323389cb3d9b5b329ef678e8fca0faf61e555a41be62036","icon-192.png":"df53ca857ce086d5d1acc89677b3a6cc67dc7518a801db8f798f5e8b8fe84011","icon-512.png":"31955caae6655dd6551a18fe6bbe082c4172ae02dc1792bbbbcf5942328a8c56","icon.svg":"d72e2a7d66220bcf075118e433de61a94b93c5d694cfafb45a7e1d15a176f832","manifest-light.webmanifest":"a8ce30e010f524098f41a88247aa1f8aa2bbd333fe8e29ddca3f59393c3d1ee1","manifest.webmanifest":"9ef05d0f4e3570c96fa952fa02a6f1904a22f7ea6187e764d0ca694742e74a39"}};
const scope=new URL(self.registration.scope);
const freshPaths=new Set(['update.html','update.js','update.css','version.json'].map(p=>new URL(p,scope).pathname));
async function digest(response){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await response.arrayBuffer())),b=>b.toString(16).padStart(2,'0')).join('');}
async function prepare(){
 const cache=await caches.open(CACHE);
 try{
  await Promise.all(ASSETS.map(async path=>{
   const url=new URL(path,scope),key=path.replace(/^\.\//,'');
   const existing=await cache.match(url);if(existing&&await digest(existing.clone())===RELEASE.assets[key])return;
   const network=new URL(url);network.searchParams.set('build',RELEASE.build);
   const response=await fetch(network,{cache:'no-store',signal:AbortSignal.timeout(20000)});
   if(!response.ok||await digest(response.clone())!==RELEASE.assets[key])throw Error('Incomplete release: '+key);
   await cache.put(url,response);
  }));
 }catch(error){await caches.delete(CACHE);throw error;}
}
self.addEventListener('install',event=>event.waitUntil(prepare()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const key of await caches.keys())if(key.startsWith(PREFIX)&&!key.slice(PREFIX.length).includes('/')&&key!==CACHE)await caches.delete(key);await self.clients.claim();})()));
self.addEventListener('message',event=>{
 if(event.data?.type==='GET_BUILD_INFO')event.ports[0]?.postMessage({build:RELEASE.build,version:RELEASE.version,environment:RELEASE.environment});
 if(event.data?.type==='ACTIVATE_UPDATE'&&event.data.build===RELEASE.build)event.waitUntil(self.skipWaiting().then(()=>event.ports[0]?.postMessage({ok:true})));
});
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==scope.origin)return;
 // Recovery and release metadata always come from the network, never an old shell.
 if(freshPaths.has(url.pathname)){event.respondWith(fetch(event.request,{cache:'no-store'}));return;}
 event.respondWith((async()=>{
  const cache=await caches.open(CACHE),shell=event.request.mode==='navigate'&&(url.pathname===scope.pathname||url.pathname===new URL('index.html',scope).pathname);
  const cached=await cache.match(shell?new URL('index.html',scope):event.request);
  if(cached)return cached;
  return fetch(event.request);
 })());
});
