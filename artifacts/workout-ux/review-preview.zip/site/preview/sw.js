/* Updates activate only after an explicit user request. */
const PREFIX='gymbro-'+self.registration.scope;
const CACHE=PREFIX+'f15c77b9143f';
const ASSETS=["./index.html","./src/active-workout.js","./src/analytics.js","./src/app-updates.css","./src/app-updates.js","./src/app.js","./src/appearance-init.js","./src/backup.js","./src/calendar.js","./src/coach-contract.js","./src/coach-local.js","./src/coach-session.js","./src/coach.js","./src/engine.js","./src/environment.js","./src/exercise-browser-controller.js","./src/exercise-browser-ui.js","./src/exercise-browser.js","./src/exercises.js","./src/extensions.js","./src/legacy-import.js","./src/model.js","./src/muscle-contributions.js","./src/muscle-map.js","./src/planner.js","./src/refinement.css","./src/storage.js","./src/style.css","./src/training-tools.js","./src/ui.js","./src/upgrade-controller.js","./src/upgrade-ui.js","./src/upgrade.css","./src/weekly-review-ui.js","./src/weekly-review.js","./src/workout-ux.css","./icon-192.png","./icon-512.png","./icon.svg","./manifest-light.webmanifest","./manifest.webmanifest"];
const RELEASE={"schema":1,"version":"0.2.4","build":"f15c77b9143f","environment":"preview","assets":{"index.html":"dd7bb67211cc66c0ec3b5a36e8e54a098bf82866b24a763f6bf11cc20b360591","src/active-workout.js":"fe4a3b8b4d8c26940c3e785ae9335daefd7227d0aff839328e77fb06901d6a65","src/analytics.js":"65e7148d769a85bc93743b120093dba323c29f0e4d9fbb4b4d6dedff528004a3","src/app-updates.css":"03726d4ccd5f4a45795d3d2512ab035e5039669e7eb256cb899f07b5bdd61022","src/app-updates.js":"0b5fe1b2bf7783b0333f54e92288d1e029dab045ef6ad89c19157c0fd7e207b5","src/app.js":"fdbebf06c67b75e224186538d91f62a135d981ac9a1ff0c106a4ff91e577309f","src/appearance-init.js":"189361ebfa9f9cf21d4c7569d277dc0d77f5b0ed42c4a9f374c6e862778ee325","src/backup.js":"8e969a66c58056e079fff7729630db87602e3d87c36e75d264026b752ea3ccc3","src/calendar.js":"204ea604e44c957c86c577258fc168d02946ec2c7e87de9dcfc56fd5e17959eb","src/coach-contract.js":"0f84c56f24ff220074a56c00a396dacb068132ce5d374e921b9724c111d8b192","src/coach-local.js":"0147d0189c8971040202118a15256098faa70245195325e09ebcc084d68c80ab","src/coach-session.js":"b44e3fa15cb016130c826139cbba41008e1bfaae9749fc5ab357c38d92e743ab","src/coach.js":"e639fd5f77a5c73a55038121a5c4080861847d1fa646d809b1fa887950f3069a","src/engine.js":"f72fdd8121d99a169b9d80bbb53418b2ba75b91d3e7cb8b8cab537d6e38ebd88","src/environment.js":"939d1403491493c0b75ac086acb657c99e7a81921590805c14a8a13d09b87d8f","src/exercise-browser-controller.js":"3f53f778a7ac700fcab4bd0af80e77f0d262012e152ab3e37c2088088113cad7","src/exercise-browser-ui.js":"c3ea0ab44e6e7c19e945f21324bdc6ce10b43426881131c7db6022bead877806","src/exercise-browser.js":"fdc1d949d2d836e5c9cdc8a7c7dbb4d87be439210df282ddad20f631d2449b5e","src/exercises.js":"d8d2ee606e95adf62aafdf9bd41aeed541deacbd7c608074e3b4b4c86cfcc566","src/extensions.js":"9429e0d6530930857beba8d7220143c64e4c96167c4686e1172415154014d692","src/legacy-import.js":"a850541d5486e63d42de830901db37d3df4643932f514e0150c7abb684e62064","src/model.js":"a691963d2467d2b0a06f19f21ddc6f19c1773bb53e0f08db34c61392f90c84de","src/muscle-contributions.js":"abcd79dc5226ec31708bab79d594eb63cb26252e0c590bea7cdca2f5ff28aa20","src/muscle-map.js":"4ba0f81607899ec77008809ae3f79d9c59cc703dc3cb0d566547cfcb20bc5c78","src/planner.js":"c087d424aa916caddd34d7f098d83ec7f00d0ea3eab7f57afccbfc7247056c07","src/refinement.css":"e3eee204646e8933b36f32db91a274bb6d5315a6893f723a43526fd8f9b89ea3","src/storage.js":"157605f8dd3e1c7faeb8b5fb0202c350f363f03d719f9846a707aed5871beb05","src/style.css":"cd648e7d351bc95756f1448c53257c636f2013db1e980bac8e69e18e0df5bfae","src/training-tools.js":"8d3462e1c4ab97bb393fa6fab95fce3a0021e3647e3960f53de97a6c5473e658","src/ui.js":"a0bd77d243068a7f3b23494a95e2d2ba22e9c25db1cafb27b38ba97232364d67","src/upgrade-controller.js":"3ddf99bb7ed0b1144ab7a83fc31f6d34b810331a78d6580c8ad81da15226ad04","src/upgrade-ui.js":"4683fdd1cdf47737387bfab349d70098e9e7f0db8291d43a80ca36d0e3724c87","src/upgrade.css":"b003ddee309e466b4f7040a7df097dc9b5f95ee19f5473aea8772fa77fb96f84","src/weekly-review-ui.js":"48f62e5496f275ddf727f2f47495208e6a79e45b984cea91c669fe3ac3dbc02f","src/weekly-review.js":"62a788c1e96469c7f323389cb3d9b5b329ef678e8fca0faf61e555a41be62036","src/workout-ux.css":"e8b859e6ea2c92922e436ad50e455a2ecb7bcec5d5a97c1e09bf58081d586b74","icon-192.png":"df53ca857ce086d5d1acc89677b3a6cc67dc7518a801db8f798f5e8b8fe84011","icon-512.png":"31955caae6655dd6551a18fe6bbe082c4172ae02dc1792bbbbcf5942328a8c56","icon.svg":"d72e2a7d66220bcf075118e433de61a94b93c5d694cfafb45a7e1d15a176f832","manifest-light.webmanifest":"35467e5cd466ea8330b34de0c6b28a2238733207811239f5738d1660f0face61","manifest.webmanifest":"7e67db5e5b8a535d87c60f784cd13fea37d129cc080c1cebb22a415917de7b2a"}};
const scope=new URL(self.registration.scope);
const freshPaths=new Set(['update.html','update.js','update.css','version.json'].map(p=>new URL(p,scope).pathname));
async function digest(response){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await response.arrayBuffer())),b=>b.toString(16).padStart(2,'0')).join('');}
async function prepare(){
 const cache=await caches.open(CACHE);
 try{
  await Promise.all(ASSETS.map(async path=>{
   const url=new URL(path,scope),key=path.replace(/^\.\//,'');
   const existing=await cache.match(url);if(existing&&await digest(existing.clone())===RELEASE.assets[key])return;
   const network=new URL(url);network.searchParams.set('build',RELEASE.build);
   const response=await fetch(network,{cache:'no-store',signal:AbortSignal.timeout(20000)});
   if(!response.ok||await digest(response.clone())!==RELEASE.assets[key])throw Error('Incomplete release: '+key);
   await cache.put(url,response);
  }));
 }catch(error){await caches.delete(CACHE);throw error;}
}
self.addEventListener('install',event=>event.waitUntil(prepare()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const key of await caches.keys())if(key.startsWith(PREFIX)&&!key.slice(PREFIX.length).includes('/')&&key!==CACHE)await caches.delete(key);await self.clients.claim();})()));
self.addEventListener('message',event=>{
 if(event.data?.type==='GET_BUILD_INFO')event.ports[0]?.postMessage({build:RELEASE.build,version:RELEASE.version,environment:RELEASE.environment});
 if(event.data?.type==='ACTIVATE_UPDATE'&&event.data.build===RELEASE.build)event.waitUntil(self.skipWaiting().then(()=>event.ports[0]?.postMessage({ok:true})));
});
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==scope.origin)return;
 // Recovery and release metadata always come from the network, never an old shell.
 if(freshPaths.has(url.pathname)){event.respondWith(fetch(event.request,{cache:'no-store'}));return;}
 event.respondWith((async()=>{
  const cache=await caches.open(CACHE),shell=event.request.mode==='navigate'&&(url.pathname===scope.pathname||url.pathname===new URL('index.html',scope).pathname);
  const cached=await cache.match(shell?new URL('index.html',scope):event.request);
  if(cached)return cached;
  return fetch(event.request);
 })());
});
